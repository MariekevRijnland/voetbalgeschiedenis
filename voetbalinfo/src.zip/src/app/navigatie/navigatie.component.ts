import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigatie',
  templateUrl: './navigatie.component.html',
  styleUrls: ['./navigatie.component.scss']
})
export class NavigatieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
